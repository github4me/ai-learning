"""Week 3: hidden-layer ReLU with a linear regression output. Standard Python only."""
import math

def relu(x):
    return max(0, x)


def neuron(inputs, weights, bias, activation=relu):
    if len(inputs) != len(weights):
        raise ValueError("Each input must have a corresponding weight")
    total = sum(x * w for x, w in zip(inputs, weights)) + bias
    return total if activation is None else activation(total)


def layer(inputs, weights, biases, activation=relu):
    if len(weights) != len(biases):
        raise ValueError("Each output neuron must have a bias")
    return [neuron(inputs, row, bias, activation)
            for row, bias in zip(weights, biases)]

if __name__ == "__main__":
    hidden = layer([1, 2], [[0.5, 0.4], [-0.3, 0.8]], [0.1, -0.2])
    prediction = layer(hidden, [[0.7, 0.2]], [0.1], activation=None)
    negative = layer(hidden, [[-1.0, 0.0]], [0.0], activation=None)
    assert math.isclose(prediction[0], 1.3)
    assert math.isclose(negative[0], -1.4)
    print("hidden=", hidden, "prediction=", prediction, "negative=", negative)

